1.0
===================

* Número Sequencial é obrigatório e Nosso Número é somente leitura.
* A classe de cada banco implementa o método getNossoNumero().